<?php

/**
 * 清理脚本 - 删除错误的表并重新安装
 */

require_once __DIR__ . '/../../vendor/autoload.php';

// 初始化Laravel应用
$app = require_once __DIR__ . '/../../bootstrap/app.php';
$app->make('Illuminate\Contracts\Console\Kernel')->bootstrap();

use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\DB;

echo "开始清理每日签到插件数据...\n";
echo str_repeat("=", 50) . "\n";

try {
    // 1. 删除外键约束（如果存在）
    echo "1. 删除外键约束...\n";
    
    if (Schema::hasTable('daily_checkins')) {
        try {
            DB::statement('ALTER TABLE daily_checkins DROP FOREIGN KEY daily_checkins_user_id_foreign');
            echo "   ✓ 删除 daily_checkins 外键约束\n";
        } catch (Exception $e) {
            echo "   - daily_checkins 外键约束不存在或已删除\n";
        }
    }
    
    if (Schema::hasTable('checkin_stats')) {
        try {
            DB::statement('ALTER TABLE checkin_stats DROP FOREIGN KEY checkin_stats_user_id_foreign');
            echo "   ✓ 删除 checkin_stats 外键约束\n";
        } catch (Exception $e) {
            echo "   - checkin_stats 外键约束不存在或已删除\n";
        }
    }

    // 2. 删除表
    echo "\n2. 删除数据表...\n";
    
    if (Schema::hasTable('daily_checkins')) {
        Schema::dropIfExists('daily_checkins');
        echo "   ✓ 删除 daily_checkins 表\n";
    } else {
        echo "   - daily_checkins 表不存在\n";
    }
    
    if (Schema::hasTable('checkin_stats')) {
        Schema::dropIfExists('checkin_stats');
        echo "   ✓ 删除 checkin_stats 表\n";
    } else {
        echo "   - checkin_stats 表不存在\n";
    }

    // 3. 删除插件记录（如果存在）
    echo "\n3. 删除插件记录...\n";
    
    $deleted = DB::table('v2_plugin')->where('code', 'daily_checkin')->delete();
    if ($deleted > 0) {
        echo "   ✓ 删除插件记录\n";
    } else {
        echo "   - 插件记录不存在\n";
    }

    // 4. 清理迁移记录
    echo "\n4. 清理迁移记录...\n";
    
    $migrations = [
        '2024_01_01_000001_create_daily_checkins_table',
        '2024_01_01_000002_create_checkin_stats_table'
    ];
    
    foreach ($migrations as $migration) {
        $deleted = DB::table('migrations')->where('migration', $migration)->delete();
        if ($deleted > 0) {
            echo "   ✓ 删除迁移记录: {$migration}\n";
        } else {
            echo "   - 迁移记录不存在: {$migration}\n";
        }
    }

    echo "\n" . str_repeat("=", 50) . "\n";
    echo "✅ 清理完成！现在可以重新安装插件了。\n";
    echo "\n下一步:\n";
    echo "php install.php install\n";

} catch (Exception $e) {
    echo "\n❌ 清理失败: " . $e->getMessage() . "\n";
    echo "请手动检查数据库状态。\n";
    exit(1);
}
