<?php

namespace Plugin\DailyCheckin;

use App\Services\Plugin\AbstractPlugin;
use Plugin\DailyCheckin\Services\CheckinService;
use Illuminate\Support\Facades\Route;

class Plugin extends AbstractPlugin
{
    /**
     * 插件启动时调用
     */
    public function boot(): void
    {
        // 注册路由
        $this->registerRoutes();

        // 注册钩子监听器
        $this->registerHooks();

        // 注册视图
        $this->registerViews();

        // 注册命令
        $this->registerCommands();
    }

    /**
     * 插件安装时调用
     */
    public function install(): void
    {
        // 运行数据库迁移
        $this->runMigrations();
    }

    /**
     * 插件卸载时调用
     */
    public function uninstall(): void
    {
        // 清理数据
        $this->cleanupData();
    }

    /**
     * 插件更新时调用
     */
    public function update(string $oldVersion, string $newVersion): void
    {
        // 处理版本更新逻辑
    }

    /**
     * 注册路由
     */
    protected function registerRoutes(): void
    {
        Route::prefix('api/v1/plugin/daily-checkin')
            ->middleware(['auth:sanctum'])
            ->group(function () {
                Route::get('/status', [\Plugin\DailyCheckin\Controllers\CheckinController::class, 'getStatus']);
                Route::post('/checkin', [\Plugin\DailyCheckin\Controllers\CheckinController::class, 'checkin']);
                Route::get('/history', [\Plugin\DailyCheckin\Controllers\CheckinController::class, 'getHistory']);
                Route::get('/ranking', [\Plugin\DailyCheckin\Controllers\CheckinController::class, 'getRanking']);
            });

        // 管理员路由
        Route::prefix('api/v1/admin/plugin/daily-checkin')
            ->middleware(['auth:sanctum', 'admin'])
            ->group(function () {
                Route::get('/stats', [\Plugin\DailyCheckin\Controllers\AdminController::class, 'getStats']);
                Route::get('/records', [\Plugin\DailyCheckin\Controllers\AdminController::class, 'getRecords']);
                Route::delete('/records/{id}', [\Plugin\DailyCheckin\Controllers\AdminController::class, 'deleteRecord']);
                Route::get('/config', [\Plugin\DailyCheckin\Controllers\AdminController::class, 'getConfig']);
                Route::post('/config', [\Plugin\DailyCheckin\Controllers\AdminController::class, 'updateConfig']);
                Route::post('/reset-stats', [\Plugin\DailyCheckin\Controllers\AdminController::class, 'resetUserStats']);
            });
    }

    /**
     * 注册钩子
     */
    protected function registerHooks(): void
    {
        // 用户登录时显示签到提醒
        $this->listen('user.login', [$this, 'onUserLogin']);
        
        // 在用户面板添加签到入口
        $this->filter('user.dashboard.widgets', [$this, 'addDashboardWidget']);
    }

    /**
     * 注册视图
     */
    protected function registerViews(): void
    {
        // 注册视图命名空间
        view()->addNamespace('DailyCheckin', $this->getViewsPath());
    }

    /**
     * 用户登录事件处理
     */
    public function onUserLogin($user): void
    {
        if (!$this->isEnabled()) {
            return;
        }

        $checkinService = new CheckinService();
        $todayChecked = $checkinService->hasTodayChecked($user->id);
        
        if (!$todayChecked) {
            // 可以在这里添加签到提醒逻辑
            // 比如发送通知或设置session提醒
        }
    }

    /**
     * 添加仪表板小部件
     */
    public function addDashboardWidget($widgets): array
    {
        if (!$this->isEnabled()) {
            return $widgets;
        }

        $widgets[] = [
            'name' => 'daily_checkin',
            'title' => '每日签到',
            'component' => 'DailyCheckinWidget',
            'order' => 10
        ];

        return $widgets;
    }

    /**
     * 检查插件是否启用
     */
    protected function isEnabled(): bool
    {
        return (bool) $this->getConfig('enable', false);
    }

    /**
     * 运行数据库迁移
     */
    protected function runMigrations(): void
    {
        $migrationsPath = $this->getMigrationsPath();
        if (is_dir($migrationsPath)) {
            \Artisan::call('migrate', [
                '--path' => 'plugins/DailyCheckin/database/migrations',
                '--force' => true
            ]);
        }
    }

    /**
     * 注册命令
     */
    protected function registerCommands(): void
    {
        if (app()->runningInConsole()) {
            app('Illuminate\Contracts\Console\Kernel')->registerCommand(
                new \Plugin\DailyCheckin\Console\Commands\ResetContinuousCheckin()
            );
        }
    }

    /**
     * 清理数据
     */
    protected function cleanupData(): void
    {
        // 删除签到记录（可选，根据需求决定是否保留历史数据）
        // \DB::table('daily_checkins')->truncate();
    }
}
